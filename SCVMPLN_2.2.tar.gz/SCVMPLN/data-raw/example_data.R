## code to prepare `example_data` dataset goes here

usethis::use_data(example_data, overwrite = TRUE)
